from starkware.cairo.lang.compiler.error_handling import LocationError


class BoolExprLoweringError(LocationError):
    pass
